package com.mangalist.manga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MangaApplicationTests {

	@Test
	void contextLoads() {
	}

}
