package com.mangalist.manga.model;

public enum ProgressStatus {
    ONGOING,
    FINISHED,
    AXED,
}
