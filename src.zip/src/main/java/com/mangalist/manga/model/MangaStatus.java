package com.mangalist.manga.model;

public enum MangaStatus {

    To_Read,
    Reading,
    Completed,
    On_Hold,
    Dropped

}
